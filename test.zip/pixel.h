#include <stdint.h>

#pragma pack(1)

typedef uint8_t byte;

typedef struct
{
	byte B;
	byte G;
	byte R;

} pixel;


#pragma pack()
