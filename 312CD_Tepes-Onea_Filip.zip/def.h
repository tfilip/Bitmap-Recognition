//Tepes-Onea Filip 312CD

#define IMG_NAME_MAX_LENGTH 100
#define MAX_NUMBERS 10